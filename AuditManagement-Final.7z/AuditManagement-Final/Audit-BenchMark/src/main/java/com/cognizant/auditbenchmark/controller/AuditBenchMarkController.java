package com.cognizant.auditbenchmark.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.auditbenchmark.exception.AuthorizationException;
import com.cognizant.auditbenchmark.feign.AuthorizationClient;
import com.cognizant.auditbenchmark.model.AuditBenchMark;
import com.cognizant.auditbenchmark.service.AuditBenchMarkServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/benchmark")
@Slf4j
@Api(value = "AuditBenchMarkController")
public class AuditBenchMarkController {
	@Autowired
	AuditBenchMarkServiceImpl auditBenchMarkService;
	@Autowired
	AuthorizationClient authClient;

	/*
	 * GetMapping to return a list of AuditBenchMark
	 */
	@ApiOperation(value = "Get list of AuditBenchMark", response = List.class)
	@GetMapping("/AuditBenchmark")
	public ResponseEntity<List<AuditBenchMark>> getAuditBenchMark(
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader)
			throws AuthorizationException {
		log.info("Inside getAuditBenchMark()");
		if (authClient.authorizeTheRequest(requestTokenHeader)) {
			log.info("End getAuditBenchMark()");
			return new ResponseEntity<List<AuditBenchMark>>(auditBenchMarkService.getBenchMarks(), HttpStatus.OK);
		} else {
			log.info("End getAuditBenchMark()");
			return new ResponseEntity<List<AuditBenchMark>>(HttpStatus.FORBIDDEN);
		}
	}
}
