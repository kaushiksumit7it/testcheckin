package com.cognizant.auditbenchmark.exception;

import lombok.extern.slf4j.Slf4j;

@SuppressWarnings("serial")
@Slf4j
public class AuthorizationException extends Exception {

	public AuthorizationException(String message) {
		super(message);
		log.info("Inside AuthorizationException()");
		log.info("End AuthorizationException()");
	}
}
