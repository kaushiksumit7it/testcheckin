package com.cognizant.auditbenchmark.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

@Getter
@Slf4j
public class ExceptionDetails {

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	private LocalDateTime timeStamp;
	private HttpStatus status;
	private String message;

	public ExceptionDetails(LocalDateTime timeStamp, HttpStatus status, String message) {
		super();
		log.info("Inside ExceptionDetails()");
		this.timeStamp = timeStamp;
		this.status = status;
		this.message = message;
		log.info(("End ExceptionDetails()"));
	}
}