package com.cognizant.auditbenchmark.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
@Table(name = "auditbenchmark")
public class AuditBenchMark {

	@Id
	@Column(name = "audittypeid")
	@ApiModelProperty(notes = "AuditType ID", name = "auditTypeId")
	public int auditTypeId;

	@Column(name = "audittype")
	@ApiModelProperty(notes = "Audit Type Name", name = "auditType")
	public String auditType;

	@Column(name = "maxnovalue")
	@ApiModelProperty(notes = "Maximum Number of No Values", name = "maxNoValue")
	public int maxNoValue;

}
