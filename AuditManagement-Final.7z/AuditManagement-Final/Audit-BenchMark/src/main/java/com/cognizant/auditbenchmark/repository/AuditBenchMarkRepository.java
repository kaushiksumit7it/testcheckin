package com.cognizant.auditbenchmark.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.auditbenchmark.model.AuditBenchMark;

public interface AuditBenchMarkRepository extends JpaRepository<AuditBenchMark, Integer> {

}
