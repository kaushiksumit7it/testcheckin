package com.cognizant.auditbenchmark.service;

import java.util.List;

import com.cognizant.auditbenchmark.model.AuditBenchMark;

public interface AuditBenchMarkService {
	List<AuditBenchMark> getBenchMarks();

}
