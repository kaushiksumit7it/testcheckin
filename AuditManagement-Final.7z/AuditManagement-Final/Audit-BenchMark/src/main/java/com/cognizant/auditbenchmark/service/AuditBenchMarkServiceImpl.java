package com.cognizant.auditbenchmark.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.auditbenchmark.model.AuditBenchMark;
import com.cognizant.auditbenchmark.repository.AuditBenchMarkRepository;

@Service
public class AuditBenchMarkServiceImpl implements AuditBenchMarkService {

	@Autowired
	AuditBenchMarkRepository repo;

	@Override
	public List<AuditBenchMark> getBenchMarks() {
		return repo.findAll();
	}

}
