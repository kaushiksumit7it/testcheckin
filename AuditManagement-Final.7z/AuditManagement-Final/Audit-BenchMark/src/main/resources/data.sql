insert into auditbenchmark (audittypeid, audittype, maxnovalue) values (1, 'Internal', 3);
insert into auditbenchmark (audittypeid, audittype, maxnovalue) values (2, 'SOX', 1);