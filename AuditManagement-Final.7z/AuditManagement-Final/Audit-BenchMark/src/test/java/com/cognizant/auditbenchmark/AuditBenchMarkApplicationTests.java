package com.cognizant.auditbenchmark;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class AuditBenchMarkApplicationTests {

	/*
	 * Testing Main func of AuditBenchMarkApplication
	 */
	@Test
	void contextLoads() {
		log.info("Inside contextLoads()");
		AuditBenchMarkApplication.main(new String[] {});
		assertTrue(true);
		log.info("End contextLoads()");
	}

}
