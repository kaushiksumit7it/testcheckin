package com.cognizant.auditbenchmark.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cognizant.auditbenchmark.exception.AuthorizationException;
import com.cognizant.auditbenchmark.feign.AuthorizationClient;
import com.cognizant.auditbenchmark.model.AuditBenchMark;
import com.cognizant.auditbenchmark.service.AuditBenchMarkServiceImpl;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class AuditBenchMarkControllerTests {

	@Mock
	AuditBenchMarkServiceImpl auditService;

	@Mock
	AuthorizationClient authClient;

	@InjectMocks
	AuditBenchMarkController auditBenchMarkControllerMock;

	@BeforeEach
	void setUp() throws Exception {
	}

	/*
	 * Testing getAuditBenchmarks()
	 * 
	 */
	@Test
	void AuditBenchMarkController_GetAuditBenchmarks() throws AuthorizationException {
		log.info("Inside AuditBenchMarkController_GetAuditBenchMarks()");
		when(auditService.getBenchMarks()).thenReturn(getAuditList());
		when(authClient.authorizeTheRequest("token")).thenReturn(true);
		ResponseEntity<List<AuditBenchMark>> auditBenchmarks = auditBenchMarkControllerMock.getAuditBenchMark("token");
		assertEquals(getAuditList().toString(), auditBenchmarks.getBody().toString());
		log.info("End AuditBenchMarkController_GetAuditBenchMarks()");
	}

	/*
	 * Function to get expected list of AuditBenchMarks
	 */
	@Test
	void testTokenInvalid() throws Exception {
		when(authClient.authorizeTheRequest("token")).thenReturn(false);
		assertEquals(HttpStatus.FORBIDDEN, auditBenchMarkControllerMock.getAuditBenchMark("token").getStatusCode());
	}

	List<AuditBenchMark> getAuditList() {
		log.info("Inside getAuditList()");
		AuditBenchMark audit1 = new AuditBenchMark(1, "Internal", 3);
		AuditBenchMark audit2 = new AuditBenchMark(2, "SOX", 1);
		List<AuditBenchMark> listAudit = new ArrayList<>();
		listAudit.add(audit1);
		listAudit.add(audit2);
		log.info("End getAuditList()");
		return listAudit;
	}

}
