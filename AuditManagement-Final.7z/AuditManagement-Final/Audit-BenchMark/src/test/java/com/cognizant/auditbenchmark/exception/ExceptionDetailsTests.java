package com.cognizant.auditbenchmark.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class ExceptionDetailsTests {

	@Mock
	ExceptionDetails exceptionDetail;

	/*
	 * Function to run before each @Test
	 */
	@BeforeEach
	void exceptionDetails_SettingValues() {
		log.info("Inside exceptionDetails_SettingValues()");
		exceptionDetail = new ExceptionDetails(LocalDateTime.now(), HttpStatus.FORBIDDEN, "ExceptionDetailsTest");
		log.info("End exceptionDetails_SettingValues()");
	}

	/*
	 * Testing for AllArgsConstructor and Getters
	 */
	@Test
	void exceptionDetails_AllArgsConstructor() {
		log.info("Inside exceptionDetails_AllArgsConstructor()");
		assertEquals("ExceptionDetailsTest", exceptionDetail.getMessage());
		assertEquals(LocalDateTime.now().getMonth(), exceptionDetail.getTimeStamp().getMonth());
		assertEquals(HttpStatus.FORBIDDEN, exceptionDetail.getStatus());
		log.info("End ExceptionDetailsTest()");
	}

}
