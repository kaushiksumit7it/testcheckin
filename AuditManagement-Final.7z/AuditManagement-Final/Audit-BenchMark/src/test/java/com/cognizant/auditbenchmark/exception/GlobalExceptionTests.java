package com.cognizant.auditbenchmark.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@SpringBootTest
class GlobalExceptionTests {

	@InjectMocks
	GlobalExceptionHandler globalExceptionHandler;
	@Mock
	ExceptionDetails customErrorResponse;

	@BeforeEach
	public void setUp() {
		customErrorResponse = new ExceptionDetails(LocalDateTime.now(), HttpStatus.UNAUTHORIZED, "test message");
		globalExceptionHandler = new GlobalExceptionHandler();
	}

	@Test
	void handlesAuthorizationExceptionTest() {
		AuthorizationException e = new AuthorizationException("message");
		globalExceptionHandler.exceptionDetails(e);
		ResponseEntity<?> entity = new ResponseEntity<>(customErrorResponse, HttpStatus.FORBIDDEN);
		assertEquals(403, entity.getStatusCodeValue());
	}

	@Test
	void handlesMissingRequestHeaderExceptionTest() {
		Exception e = new Exception("message");
		globalExceptionHandler.handleMissingRequestHeaderException(e);
		ResponseEntity<?> entity = new ResponseEntity<>(customErrorResponse, HttpStatus.BAD_REQUEST);
		assertEquals(400, entity.getStatusCodeValue());
	}

}
