package com.cognizant.auditbenchmark.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * This class contains test cases for the AuditBenchMark model class which are
 * written using junit
 *
 */

@SpringBootTest
@Slf4j
class AuditBenchMarkTests {

	@Mock
	AuditBenchMark auditBenchMark;

	/*
	 * Tests to run before each
	 * 
	 * @Test
	 */
	@BeforeEach
	void setUp() throws Exception {
		log.info("Inside setUp()");
		auditBenchMark = new AuditBenchMark(1, "Internal", 2);
		log.info("End setUp()");
	}

	/**
	 * Checking if AuditBenchMark class is loading or not.
	 */
	@Test
	@DisplayName("Checking if Claim class is loading or not.")
	void claimIsLoadedOrNot() {
		log.info("Inside claimIsLoadedOrNot()");
		assertThat(auditBenchMark).isNotNull();
		log.info("End claimIsLoadedOrNot()");
	}

	/**
	 * 
	 * Testing AuditBenchMark Constructor
	 */
	@Test
	void testBenefitsConstructor() {
		log.info("Inside testBenefitsConstructor()");
		assertEquals(1, auditBenchMark.getAuditTypeId());
		assertEquals("Internal", auditBenchMark.getAuditType());
		assertEquals(2, auditBenchMark.getMaxNoValue());
		log.info("End testBenefitsConstructor()");
	}

	/**
	 * 
	 * Testing Getters and setters
	 */
	@Test
	void testGettersSetters() {
		log.info("Inside testGettersSetters");
		auditBenchMark.setAuditTypeId(2);
		auditBenchMark.setAuditType("SOX");
		auditBenchMark.setMaxNoValue(3);
		assertEquals(2, auditBenchMark.getAuditTypeId());
		assertEquals("SOX", auditBenchMark.getAuditType());
		assertEquals(3, auditBenchMark.getMaxNoValue());
		log.info("End testGettersSetters");
	}

	/**
	 * Testing AuditBenchmark toString() method
	 */
	@Test
	void testToString() {
		log.info("Inside testToString()");
		String s = auditBenchMark.toString();
		assertEquals(auditBenchMark.toString(), s);
		log.info("End testToString()");

	}

	/*
	 * 
	 * test the AuditBenchMark no argsConstructor
	 */

	@Test
	void testNoArgConstructor() {
		log.info("Inside testNoArgConstructor()");
		AuditBenchMark ulc = new AuditBenchMark();
		assertEquals(new AuditBenchMark().toString(), ulc.toString());
		log.info("End testNoArgConstructor()");
	}

}
