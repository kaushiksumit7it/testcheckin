package com.cognizant.auditbenchmark.repository;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

@DataJpaTest(showSql = true)
class AuditBenchMarkRepositoryTest {
	@Autowired
	AuditBenchMarkRepository repo;

	/*
	 * Test to check if repository returns correct no of elements
	 */
	@Test
	void test() {
		assertThat(repo.findAll()).hasSize(2);
	}

}
