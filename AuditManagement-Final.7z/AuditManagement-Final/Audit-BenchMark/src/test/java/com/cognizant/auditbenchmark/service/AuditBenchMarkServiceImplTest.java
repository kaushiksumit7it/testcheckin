package com.cognizant.auditbenchmark.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cognizant.auditbenchmark.model.AuditBenchMark;
import com.cognizant.auditbenchmark.repository.AuditBenchMarkRepository;

@ExtendWith(MockitoExtension.class)
class AuditBenchMarkServiceImplTest {
	private AuditBenchMark b1;
	private AuditBenchMark b2;

	@BeforeEach
	public void setup() {
		b1 = new AuditBenchMark(1, "internal", 3);
		b2 = new AuditBenchMark(2, "SOX", 1);
	}

	@InjectMocks
	AuditBenchMarkServiceImpl bmService;

	@Mock
	AuditBenchMarkRepository mockRepo;

	@Test
	void test() {
		when(mockRepo.findAll()).thenReturn(Arrays.asList(b1, b2));
		assertThat(bmService.getBenchMarks()).hasSize(2);

	}

}
