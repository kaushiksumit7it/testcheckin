package com.cognizant.auditchecklist.exception;

@SuppressWarnings("serial")
public class AuditCheckListNotFoundException extends Exception {
	public AuditCheckListNotFoundException(String message) {
		super(message);
	}

}
