package com.cognizant.auditchecklist.exception;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

@SpringBootTest
@ContextConfiguration
class AuditCheckListNotFoundExceptionTest {

	@Mock
	AuditCheckListNotFoundException auditCheckListnotFoundException;

	@Test
	void contextLoads() {
		assertNotNull(auditCheckListnotFoundException);
	}

	@Test
	void testConstructor() {
		assertNotNull(new AuditCheckListNotFoundException("Exception"));
	}

}
