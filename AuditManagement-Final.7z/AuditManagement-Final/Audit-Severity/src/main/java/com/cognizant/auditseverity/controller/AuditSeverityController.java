package com.cognizant.auditseverity.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.auditseverity.exception.AuthorizationException;
import com.cognizant.auditseverity.feignclient.AuthorizationClient;
import com.cognizant.auditseverity.feignclient.BenchmarkFeign;
import com.cognizant.auditseverity.model.AuditBenchMark;
import com.cognizant.auditseverity.model.AuditRequest;
import com.cognizant.auditseverity.model.AuditResponse;
import com.cognizant.auditseverity.service.AuditSeverityService;

@RestController

@RequestMapping("/severity")
public class AuditSeverityController {
	@Autowired
	BenchmarkFeign benchMarkClient;
	@Autowired
	AuditResponse auditResponse;
	@Autowired
	AuditSeverityService auditServerityService;
	@Autowired
	AuthorizationClient authClient;

	@PostMapping("/AuditSeverity")
	public ResponseEntity<AuditResponse> getStatus(@RequestBody AuditRequest auditRequest,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader)
			throws AuthorizationException {
		if (authClient.authorizeTheRequest(requestTokenHeader)) {
			ResponseEntity<AuditResponse> responseGenerated = null;
			ResponseEntity<List<AuditBenchMark>> benchMarks = benchMarkClient.getBenchMarks(requestTokenHeader);
			auditResponse = auditServerityService.checkSeverity(benchMarks.getBody(), auditRequest);
			responseGenerated = new ResponseEntity<>(auditResponse, HttpStatus.OK);
			return responseGenerated;
		} else {
			throw new AuthorizationException("Not allowed");
		}
	}

}
