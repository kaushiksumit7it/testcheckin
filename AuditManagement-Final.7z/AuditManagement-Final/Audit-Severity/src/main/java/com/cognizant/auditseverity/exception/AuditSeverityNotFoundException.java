package com.cognizant.auditseverity.exception;

@SuppressWarnings("serial")
public class AuditSeverityNotFoundException extends Exception {
public AuditSeverityNotFoundException(String message) {
	super(message);
}
}
