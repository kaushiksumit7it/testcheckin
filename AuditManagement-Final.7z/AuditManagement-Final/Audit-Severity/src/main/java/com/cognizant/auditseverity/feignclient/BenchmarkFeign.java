package com.cognizant.auditseverity.feignclient;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cognizant.auditseverity.model.AuditBenchMark;

@FeignClient(name = "AuditBenchMark-service", url = "${benchmark.URL}")
public interface BenchmarkFeign {

	@GetMapping("/AuditBenchmark")
	public ResponseEntity<List<AuditBenchMark>> getBenchMarks(
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader);
}
