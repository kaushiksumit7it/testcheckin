package com.cognizant.auditseverity.service;

import java.util.List;

import com.cognizant.auditseverity.model.AuditBenchMark;
import com.cognizant.auditseverity.model.AuditRequest;
import com.cognizant.auditseverity.model.AuditResponse;

public interface AuditSeverityService {

	public AuditResponse checkSeverity(List<AuditBenchMark> benchMarks,AuditRequest auditRequest);
}
