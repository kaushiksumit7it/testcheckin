package com.cognizant.auditseverity.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.auditseverity.model.AuditBenchMark;
import com.cognizant.auditseverity.model.AuditQuestion;
import com.cognizant.auditseverity.model.AuditRequest;
import com.cognizant.auditseverity.model.AuditResponse;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class AuditSeverityServiceImplementation implements AuditSeverityService {
	@Autowired
	AuditResponse auditResponse;
	
	@Override
	public AuditResponse checkSeverity(List<AuditBenchMark> benchMarks, AuditRequest auditRequest) {
		
		String auditType= auditRequest.getAuditDetail().getAuditType();
		int maxAcceptableNo = 0;
		for (AuditBenchMark auditBenchMark : benchMarks) {
			if(auditRequest.getAuditDetail().getAuditType().equalsIgnoreCase(auditBenchMark.getAuditType())) {
				maxAcceptableNo = auditBenchMark.getMaxNoValue(); // internal - 3, sox - 1
			}
		}
		
		List<AuditQuestion> questions=auditRequest.getAuditDetail().getAuditQuestion();
		int count=0;
		for(AuditQuestion question:questions) {
			if(question.getResponse().equalsIgnoreCase("NO")) {
				count++;
			}
		}
		log.info("AUDIT TYPE : " + auditType);
		if(auditType.equalsIgnoreCase("internal") && count<=maxAcceptableNo) {
			auditResponse.setAuditId(UUID.randomUUID()+"");
			auditResponse.setAuditStatus("GREEN");
			auditResponse.setRemedialActionDuration("No action needed");
		} else if(auditType.equalsIgnoreCase("internal") && count>maxAcceptableNo) {
			auditResponse.setAuditId(UUID.randomUUID()+"");
			auditResponse.setAuditStatus("RED");
			auditResponse.setRemedialActionDuration("Action to be taken in 2 weeks");
		} else if(auditType.equalsIgnoreCase("sox") && count<=maxAcceptableNo) {
			auditResponse.setAuditId(UUID.randomUUID()+"");
			auditResponse.setAuditStatus("GREEN");
			auditResponse.setRemedialActionDuration("No action needed");
		} else if(auditType.equalsIgnoreCase("sox") && count>maxAcceptableNo) {
			auditResponse.setAuditId(UUID.randomUUID()+"");
			auditResponse.setAuditStatus("RED");
			auditResponse.setRemedialActionDuration("Action to be taken in 1 weeks");
		}
			return auditResponse;
	}

}
