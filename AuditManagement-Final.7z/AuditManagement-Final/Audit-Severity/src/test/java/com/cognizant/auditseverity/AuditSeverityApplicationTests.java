package com.cognizant.auditseverity;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class AuditSeverityApplicationTests {

	@Test
	void contextLoads() {
		log.info("Inside contextLoads()");
		AuditSeverityApplication.main(new String[] {});
		assertTrue(true);
		log.info("End contextLoads()");
	}

}
