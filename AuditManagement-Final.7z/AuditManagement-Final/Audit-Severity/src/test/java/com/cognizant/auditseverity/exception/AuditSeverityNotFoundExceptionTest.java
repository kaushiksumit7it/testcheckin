package com.cognizant.auditseverity.exception;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

@SpringBootTest
@ContextConfiguration
class AuditSeverityNotFoundExceptionTest {

	@Mock
	AuditSeverityNotFoundException auditSeverityNotFoundException;

	@Test
	void contextLoads() {
		assertNotNull(auditSeverityNotFoundException);
	}

	@Test
	void testConstructor() {
		assertNotNull(new AuditSeverityNotFoundException("Exception"));
	}

}
