package com.cognizant.auditseverity.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@SpringBootTest
class GlobalExceptionHandlerTest {

	@InjectMocks
	GlobalExceptionHandler globalExceptionHandler;
	@Mock
	ExceptionDetails customErrorResponse;

	@BeforeEach
	void setUp() {
		customErrorResponse = new ExceptionDetails(LocalDateTime.now(), HttpStatus.UNAUTHORIZED, "test message");
		globalExceptionHandler = new GlobalExceptionHandler();
	}

	@Test
	void handlesAuthorizationExceptionTest() {
		AuthorizationException e = new AuthorizationException("message");
		globalExceptionHandler.handleAuthorizationException(e);
		ResponseEntity<?> entity = new ResponseEntity<>(customErrorResponse, HttpStatus.FORBIDDEN);
		assertEquals(403, entity.getStatusCodeValue());
	}

	@Test
	void handlesAuditSeverityNotFoundExceptionTest() {
		AuditSeverityNotFoundException e = new AuditSeverityNotFoundException("message");
		globalExceptionHandler.handleAuditSeverityNotFoundException(e);
		ResponseEntity<?> entity = new ResponseEntity<>(customErrorResponse, HttpStatus.NOT_FOUND);
		assertEquals(404, entity.getStatusCodeValue());
	}

	@Test
	void handlesMissingRequestHeaderExceptionTest() {

		Exception e = new Exception("message");
		globalExceptionHandler.handleMissingRequestHeaderException(e);
		ResponseEntity<?> entity = new ResponseEntity<>(customErrorResponse, HttpStatus.BAD_REQUEST);
		assertEquals(400, entity.getStatusCodeValue());
	}

}
