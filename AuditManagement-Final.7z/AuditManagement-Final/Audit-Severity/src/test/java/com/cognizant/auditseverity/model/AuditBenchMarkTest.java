package com.cognizant.auditseverity.model;

import static org.assertj.core.api.Assertions.assertThat;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 
 * This class contains test cases for the AuditBenchMark model class which are
 * written using junit
 *
 */

@SpringBootTest
class AuditBenchMarkTest {

	@Mock
	AuditBenchMark auditBenchMark;

	@BeforeEach
	void setUp() throws Exception {
		auditBenchMark = new AuditBenchMark(1, "Internal", 2);
	}

	/**
	 * Checking if AuditBenchMark class is loading or not.
	 */
	@Test
	@DisplayName("Checking if AuditBenchMark class is loading or not.")
	void claimIsLoadedOrNot() {
		assertThat(auditBenchMark).isNotNull();
	}

	/**
	 * 
	 * Testing AuditBenchMark Constructor
	 */
	@Test
	void testBenefitsConstructor() {
		assertEquals(1, auditBenchMark.getAuditTypeId());
		assertEquals("Internal", auditBenchMark.getAuditType());
		assertEquals(2, auditBenchMark.getMaxNoValue());
	}

	/**
	 * 
	 * Testing Getters and setters
	 */
	@Test
	void testGettersSetters() {
		auditBenchMark.setAuditTypeId(2);
		auditBenchMark.setAuditType("SOX");
		auditBenchMark.setMaxNoValue(3);
		assertEquals(2, auditBenchMark.getAuditTypeId());
		assertEquals("SOX", auditBenchMark.getAuditType());
		assertEquals(3, auditBenchMark.getMaxNoValue());
	}

	@Test
	void testHashCodes() {
		AuditBenchMark tempAuditBenchMark = new AuditBenchMark(1, "Internal", 2);
		assertEquals(auditBenchMark.hashCode(), tempAuditBenchMark.hashCode());
	}

	@Test
	void testEquals() {
		AuditBenchMark tempAuditBenchMark = new AuditBenchMark(1, "Internal", 2);
		assertEquals(auditBenchMark, tempAuditBenchMark);
	}

	/*
	 * 
	 * test the AuditBenchMark no argsConstructor
	 */

	@Test
	void testNoArgConstructor() {
		AuditRequest ulc = new AuditRequest();
		assertEquals(ulc, ulc);
	}

	/*
	 * 
	 * test the AuditBenchMark toString()
	 */
	@Test
	void testToString() {
		String result = "AuditBenchMark(auditTypeId=" + auditBenchMark.getAuditTypeId() + ", auditType="
				+ auditBenchMark.getAuditType() + ", maxNoValue=" + auditBenchMark.getMaxNoValue() + ")";
		assertEquals(auditBenchMark.toString(), result);
	}

}
