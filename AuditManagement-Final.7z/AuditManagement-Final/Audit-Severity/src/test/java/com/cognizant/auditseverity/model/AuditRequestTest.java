package com.cognizant.auditseverity.model;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditRequestTest {

	@Mock
	AuditRequest detail;

	@InjectMocks
	AuditDetail auditdetail;

	@BeforeEach
	void setUp() throws Exception {
		this.detail = new AuditRequest("ipms", "abc", "abc", auditdetail);
	}

	@AfterEach
	void tearDown() throws Exception {
		detail = null;
		assertNull(detail);
	}

	@Test
	void testHashCodes() {
		AuditRequest tempAuditRequest = new AuditRequest("ipms", "abc", "abc", auditdetail);
		assertEquals(detail.hashCode(), tempAuditRequest.hashCode());
	}

	@Test
	void testEquals() {
		AuditRequest tempAuditRequest = new AuditRequest("ipms", "abc", "abc", auditdetail);
		assertEquals(detail, tempAuditRequest);
	}

	@Test
	void testToString() {
		String result = "AuditRequest(projectName=" + detail.getProjectName() + ", projectManagerName="
				+ detail.getProjectManagerName() + ", ApplicationOwnerName=" + detail.getApplicationOwnerName()
				+ ", auditDetail=" + detail.getAuditDetail() + ")";
		assertEquals(detail.toString(), result);
	}

	@Test
	void testGetSetProjectName() {
		detail.setProjectName("ipms");
		assertEquals("ipms", detail.getProjectName());
	}

	@Test
	void testGetSetProjectManagerName() {

		detail.setProjectManagerName("abc");
		assertEquals("abc", detail.getProjectManagerName());
	}

	@Test
	void testGetSetApplicationOwnerName() {
		detail.setApplicationOwnerName("abc");
		assertEquals("abc", detail.getApplicationOwnerName());
	}

	@Test
	void testGetSetAuditDetail() {
		detail.setAuditDetail(auditdetail);
		assertEquals(auditdetail, detail.getAuditDetail());
	}

	@Test
	void auditDetailConstructor() {
		assertNotNull(detail);
	}

	@Test
	void testauditDetailParameterizedConstructor() {
		AuditRequest auditdetails = new AuditRequest("ipms", "abc", "abc", auditdetail);
		assertEquals("ipms", auditdetails.getProjectName());
	}

}
