package com.cognizant.auditseverity.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditResponseTest {

	@Mock
	AuditResponse auditResponse;

	@BeforeEach
	void setUp() throws Exception {
		auditResponse = new AuditResponse("1", "Green", "No action needed");
	}

	/**
	 * Checking if AuditResponse class is loading or not.
	 */
	@Test
	@DisplayName("Checking if Audit Response class is loading or not.")
	void claimIsLoadedOrNot() {
		assertThat(auditResponse).isNotNull();
	}

	/**
	 * 
	 * Testing AuditResponse Constructor
	 */
	@Test
	void testBenefitsConstructor() {
		assertEquals("1", auditResponse.getAuditId());
		assertEquals("Green", auditResponse.getAuditStatus());
		assertEquals("No action needed", auditResponse.getRemedialActionDuration());
	}

	/**
	 * 
	 * Testing Getters and setters
	 */
	@Test
	void testGettersSetters() {
		auditResponse.setAuditId("1");
		auditResponse.setAuditStatus("Green");
		auditResponse.setRemedialActionDuration("No action needed");
		assertEquals("1", auditResponse.getAuditId());
		assertEquals("Green", auditResponse.getAuditStatus());
		assertEquals("No action needed", auditResponse.getRemedialActionDuration());
	}

	@Test
	void testHashCodes() {
		AuditResponse tempAuditResponse = new AuditResponse("1", "Green", "No action needed");
		assertEquals(auditResponse.hashCode(), tempAuditResponse.hashCode());
	}

	@Test
	void testEquals() {
		AuditResponse tempAuditResponse = new AuditResponse("1", "Green", "No action needed");
		assertEquals(auditResponse, tempAuditResponse);
	}

	/*
	 * 
	 * test the AuditResponse no argsConstructor
	 */

	@Test
	void testNoArgConstructor() {
		AuditResponse ulc = new AuditResponse();
		AuditResponse ulc1 = new AuditResponse();
		assertEquals(ulc, ulc1);
	}

	/*
	 * 
	 * test the AuditResponse toString()
	 */
	@Test
	void testToString() {
		String result = "AuditResponse(auditId=" + auditResponse.getAuditId() + ", auditStatus="
				+ auditResponse.getAuditStatus() + ", remedialActionDuration="
				+ auditResponse.getRemedialActionDuration() + ")";
		assertEquals(auditResponse.toString(), result);
	}

}
