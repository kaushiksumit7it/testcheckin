package com.cognizant.auditseverity.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.cognizant.auditseverity.controller.AuditSeverityController;
import com.cognizant.auditseverity.exception.AuthorizationException;
import com.cognizant.auditseverity.feignclient.AuthorizationClient;
import com.cognizant.auditseverity.feignclient.BenchmarkFeign;
import com.cognizant.auditseverity.model.AuditBenchMark;
import com.cognizant.auditseverity.model.AuditDetail;
import com.cognizant.auditseverity.model.AuditQuestion;
import com.cognizant.auditseverity.model.AuditRequest;
import com.cognizant.auditseverity.model.AuditResponse;

@SpringBootTest

class AuditSeverityServiceImplementationTest {

	@Mock
	AuthorizationClient authClient;
	@Mock
	BenchmarkFeign benchMarkClient;
	@Mock
	AuditBenchMark auditBenchMark;

	@Mock
	AuditRequest auditRequest;

	@InjectMocks
	AuditSeverityController severityController;

	@Mock
	AuditSeverityService severityService;

	@Mock
	AuditDetail auditDetail;

	@Mock
	AuditQuestion auditQuestion;

	@Mock
	AuditResponse auditResponse;

	@Mock
	ResponseEntity<AuditResponse> responseEntity;

	@Mock
	Environment env;

	@Test
	void testCheckSeverity() throws AuthorizationException {
		ResponseEntity<List<AuditBenchMark>> benchMarks = new ResponseEntity<List<AuditBenchMark>>(new ArrayList<>(),
				HttpStatus.OK);
		when(authClient.authorizeTheRequest("token")).thenReturn(true);
		when(benchMarkClient.getBenchMarks("token")).thenReturn(benchMarks);
		when(severityService.checkSeverity(benchMarks.getBody(), auditRequest)).thenReturn(auditResponse);
		List<AuditQuestion> questions = new ArrayList<>();
		questions.add(new AuditQuestion(1, "Internal", "Is data deleted with permission of user?", "Yes"));
		questions.add(new AuditQuestion(1, "Internal", "DEF", "No"));
		questions.add(new AuditQuestion(1, "Internal", "PQR", "Yes"));
		questions.add(new AuditQuestion(1, "Internal", "STU", "Yes"));
		questions.add(new AuditQuestion(1, "Internal", "QWF", "Yes"));
		ResponseEntity<AuditResponse> responseEntity = new ResponseEntity<AuditResponse>(auditResponse, HttpStatus.OK);
		assertThat(severityController.getStatus(auditRequest, "token")).isEqualTo(responseEntity);

	}
}
