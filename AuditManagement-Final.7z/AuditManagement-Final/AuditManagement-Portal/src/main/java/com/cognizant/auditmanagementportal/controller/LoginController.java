package com.cognizant.auditmanagementportal.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.auditmanagementportal.feign.AuthorisingClient;
import com.cognizant.auditmanagementportal.model.AuditType;
import com.cognizant.auditmanagementportal.model.JwtRequest;
import com.cognizant.auditmanagementportal.model.ProjectDetails;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping("/portal")
public class LoginController {
	
	@Autowired
	private AuthorisingClient client;

	/**
	 * @param user
	 * @param model
	 * @return login view
	 */
	@GetMapping(value = "/login")
	public String showLoginPage(@ModelAttribute("user") JwtRequest user, Model model) {
		return "login";
	}

	/**
	 * @param model
	 * @param request
	 * @return
	 */
	@GetMapping(value = "/logout")
	public String logoutAndShowLoginPage(Model model, HttpServletRequest request) {
		/*
		 * set session as invalidate 
		 * set username to null
		 */
		request.getSession().invalidate();
		model.addAttribute("username", null);
		return "redirect:/portal/login";
	}

	@PostMapping(value = "/login")
	public String afterLoginAuthenticateAndRedirect(@ModelAttribute("user") JwtRequest user, Model model,
			HttpServletRequest request) {
		/*
		 * call authentication microservice client
		 * generate the token
		 * if excepyions occured while generating token, redirect to same view
		 * otherwise return welcome view
		 */
		ResponseEntity<?> responseGenerated = null;
		try {
			
			responseGenerated = client.createAuthenticationToken(user);
			

		} catch (Exception e) {
			log.info(e.getMessage()+"=========================");
			e.printStackTrace();
			model.addAttribute("errorMessage", "Invalid Credentials");
			return "login";
		}
		/*
		 * retreive jwt token from map set it to session
		 */
		@SuppressWarnings("unchecked")
		Map<String, String> tokenMap = (Map<String, String>) responseGenerated.getBody();
		String token = tokenMap.get("token");
		
		request.getSession().setAttribute("Authorization", "Bearer " + token);
		request.getSession().setAttribute("userName", user.getUserName());			
		model.addAttribute("auditType", new AuditType());
		model.addAttribute("projectDetails",new ProjectDetails());
		return "home";
		
	}
	
	@ModelAttribute("auditList")
	public List<String> showAuditList() {
		List<String> auditList = new ArrayList<>();
		auditList.add("Internal");
		auditList.add("SOX");
		return auditList;
	}
}
