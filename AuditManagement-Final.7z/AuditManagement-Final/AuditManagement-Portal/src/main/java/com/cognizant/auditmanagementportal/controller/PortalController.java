package com.cognizant.auditmanagementportal.controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cognizant.auditmanagementportal.feign.AuditCheckListClient;
import com.cognizant.auditmanagementportal.feign.AuditSeverityClient;
import com.cognizant.auditmanagementportal.model.AuditDetail;
import com.cognizant.auditmanagementportal.model.AuditQuestion;
import com.cognizant.auditmanagementportal.model.AuditRequest;
import com.cognizant.auditmanagementportal.model.AuditResponse;
import com.cognizant.auditmanagementportal.model.AuditType;
import com.cognizant.auditmanagementportal.model.ProjectDetails;
import com.cognizant.auditmanagementportal.model.QuestionListWrapper;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequestMapping("/portal")
public class PortalController {

	@Autowired
	private AuditCheckListClient checkListClient;

	@Autowired
	private AuditSeverityClient severityClient;

	@Autowired
	private AuditRequest auditRequest;

	@Autowired
	private AuditResponse auditResponse;

	@Autowired
	AuditType type;

	@PostMapping("/AuditCheckListQuestions")
	public ModelAndView getQuestions(@ModelAttribute("projectDetails") ProjectDetails projectDetails,
			@ModelAttribute("auditType") AuditType auditType, HttpServletRequest request) throws Exception {
		log.info("Inside getQuestions");
		if ((String) request.getSession().getAttribute("Authorization") == null) {

			ModelAndView login = new ModelAndView("error-page401");
			return login;
		}
		type = auditType;
		ModelAndView mav = new ModelAndView("auditQuestions");
		QuestionListWrapper wrapper = new QuestionListWrapper();
		List<AuditQuestion> auditQuestions = new ArrayList<>();
		auditQuestions = checkListClient.getAuditQuestions(auditType.getAuditType(),
				(String) request.getSession().getAttribute("Authorization")).getBody();
		for (AuditQuestion auditQuestion : auditQuestions) {
			if (auditQuestion.getResponse() != null) {
				auditQuestion.setResponse(null);
			}
		}
		wrapper.setQuestionList(auditQuestions);
		mav.addObject("questionListWrapper", wrapper);
		mav.addObject("projectDetails", projectDetails);
		log.info("Project Details : " + projectDetails);
		return mav;
	}

	@PostMapping("/AuditSeverity")
	public ModelAndView calculateAuditSeverity(@ModelAttribute QuestionListWrapper questionListWrapper,
			@ModelAttribute ProjectDetails projectDetails, HttpServletRequest request) throws Exception {
		if ((String) request.getSession().getAttribute("Authorization") == null) {

			ModelAndView login = new ModelAndView("error-page401");
			return login;
		}
		ModelAndView mav = new ModelAndView();
		List<AuditQuestion> questions = checkListClient
				.saveAuditQuestionsResponse(questionListWrapper.getQuestionList(),
						(String) request.getSession().getAttribute("Authorization"))
				.getBody();
		auditRequest.setProjectName(projectDetails.getProjectName());
		auditRequest.setProjectManagerName(projectDetails.getProjectManagerName());
		auditRequest.setApplicationOwnerName(projectDetails.getApplicationOwnerName());
		auditRequest.setAuditDetail(new AuditDetail(type.getAuditType(), LocalDate.now(), questions));
		auditResponse = severityClient
				.getAuditStatus(auditRequest, (String) request.getSession().getAttribute("Authorization")).getBody();
		mav.addObject("projectName", projectDetails.getProjectName());
		mav.addObject("projectManagerName", projectDetails.getProjectManagerName());
		mav.addObject("applicationOwnerName", projectDetails.getApplicationOwnerName());
		mav.addObject("status", auditResponse.getAuditStatus());
		mav.addObject("auditId", auditResponse.getAuditId());
		mav.addObject("remedialAction", auditResponse.getRemedialActionDuration());
		mav.setViewName("auditStatus");
		return mav;
	}

	@ModelAttribute("auditList")
	public List<String> showAuditList() {
		List<String> auditList = new ArrayList<>();
		auditList.add("Internal");
		auditList.add("SOX");
		return auditList;
	}
}
