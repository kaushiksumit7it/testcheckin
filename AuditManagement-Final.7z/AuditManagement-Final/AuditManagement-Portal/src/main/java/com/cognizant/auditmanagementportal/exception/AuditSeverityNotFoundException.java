package com.cognizant.auditmanagementportal.exception;

@SuppressWarnings("serial")
public class AuditSeverityNotFoundException extends Exception {
public AuditSeverityNotFoundException(String message) {
	super(message);
}
}
