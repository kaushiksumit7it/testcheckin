package com.cognizant.auditmanagementportal.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cognizant.auditmanagementportal.exception.AuthorizationException;
import com.cognizant.auditmanagementportal.model.AuditQuestion;

@FeignClient(name = "audit-checklist-microservice", url = "${checklist.URL}")
public interface AuditCheckListClient {
	
	@PostMapping("/GetQuestions")
	public ResponseEntity<List<AuditQuestion>> getAuditQuestions(@RequestBody String auditType, @RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws AuthorizationException;
	
	@PostMapping("/SaveQuestions")
	public ResponseEntity<List<AuditQuestion>> saveAuditQuestionsResponse(@RequestBody List<AuditQuestion> auditQuestionsResponse, @RequestHeader(value = "Authorization", required = true) String requestTokenHeader) throws AuthorizationException;
}
