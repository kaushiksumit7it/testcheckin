package com.cognizant.auditmanagementportal.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cognizant.auditmanagementportal.exception.AuthorizationException;
import com.cognizant.auditmanagementportal.model.AuditRequest;
import com.cognizant.auditmanagementportal.model.AuditResponse;

@FeignClient(name = "audit-severity-microservice", url = "${severity.URL}")
public interface AuditSeverityClient {

	@PostMapping("/AuditSeverity")
	public ResponseEntity<AuditResponse> getAuditStatus(@RequestBody AuditRequest auditRequest,
			@RequestHeader(value = "Authorization", required = true) String requestTokenHeader)
			throws AuthorizationException;

}
