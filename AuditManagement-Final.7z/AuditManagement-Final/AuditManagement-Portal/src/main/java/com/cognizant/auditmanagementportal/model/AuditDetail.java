package com.cognizant.auditmanagementportal.model;

import java.time.LocalDate;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuditDetail {
	
	private String auditType;
	
	private LocalDate date;
	
	private List<AuditQuestion> auditQuestion;
}
