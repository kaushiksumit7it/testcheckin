package com.cognizant.auditmanagementportal.model;


import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
@Component
public class AuditType {
	/**
	 * Variable auditType is used to store the Type of Audit
	 */
	String auditType;

}
