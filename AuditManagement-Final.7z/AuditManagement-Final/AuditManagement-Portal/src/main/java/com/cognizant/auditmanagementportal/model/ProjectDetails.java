package com.cognizant.auditmanagementportal.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import lombok.NoArgsConstructor;



@NoArgsConstructor
@AllArgsConstructor
@Data
public class ProjectDetails {
	
	private String projectName;
	
	private String projectManagerName;
	
	private String applicationOwnerName;
	
}
