package com.cognizant.auditmanagementportal;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
class AuditManagementPortalApplicationTest {

	@Test
	void contextLoads() {
		log.info("Inside contextLoads()");
		AuditManagementPortalApplication.main(new String[] {});
		assertTrue(true);
		log.info("End contextLoads()");
	}

}
