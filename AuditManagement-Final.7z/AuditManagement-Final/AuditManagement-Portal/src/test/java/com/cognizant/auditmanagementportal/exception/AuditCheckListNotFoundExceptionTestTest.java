package com.cognizant.auditmanagementportal.exception;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditCheckListNotFoundExceptionTest {

	@Mock
	AuditCheckListNotFoundException auditCheckListNotFoundException;

	@Test
	void contextLoads() {
		assertNotNull(auditCheckListNotFoundException);
	}

	@Test
	void testConstructor() {
		assertNotNull(new AuditCheckListNotFoundException("Exception"));
	}

}
