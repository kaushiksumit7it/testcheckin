package com.cognizant.auditmanagementportal.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.WebRequest;

@SpringBootTest
class GlobalExceptionHandlerTest {

	@InjectMocks
	GlobalExceptionHandler globalExceptionHandler;
	@Mock
	ExceptionDetails customErrorResponse;

	@BeforeEach
	public void setUp() {
		customErrorResponse = new ExceptionDetails(LocalDateTime.now(), "test message");
		globalExceptionHandler = new GlobalExceptionHandler();
	}

	@Test
	void handlesAuthorizationExceptionTest() {
		Exception e = new Exception("message");
		WebRequest request = null;
		globalExceptionHandler.handleAuthorizationException(e, request);
		ResponseEntity<?> entity = new ResponseEntity<>(customErrorResponse, HttpStatus.FORBIDDEN);
		assertEquals(403, entity.getStatusCodeValue());
	}

	@Test
	void handlesAuditSeverityNotFoundExceptionTest() {
		AuditSeverityNotFoundException e = new AuditSeverityNotFoundException("message");
		WebRequest request = null;
		globalExceptionHandler.handleAuditSeverityNotFoundException(e, request);
		ResponseEntity<?> entity = new ResponseEntity<>(customErrorResponse, HttpStatus.NOT_FOUND);
		assertEquals(404, entity.getStatusCodeValue());
	}

	@Test
	void handlesMissingRequestHeaderExceptionTest() {

		Exception e = new Exception("message");
		WebRequest request = null;
		globalExceptionHandler.handleMissingRequestHeaderException(e, request);
		ResponseEntity<?> entity = new ResponseEntity<>(customErrorResponse, HttpStatus.BAD_REQUEST);
		assertEquals(400, entity.getStatusCodeValue());
	}

	@Test
	void handlesAuditCheckListNotFoundExceptionTest() {

		Exception e = new Exception("message");
		WebRequest request = null;
		globalExceptionHandler.handleAuditCheckListNotFoundException(e, request);
		ResponseEntity<?> entity = new ResponseEntity<>(customErrorResponse, HttpStatus.BAD_REQUEST);
		assertEquals(400, entity.getStatusCodeValue());
	}

}
