package com.cognizant.auditmanagementportal.model;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditDetailTest {
	@Mock
	AuditDetail detail;

	List<AuditQuestion> auditQuestion = new ArrayList<AuditQuestion>();
	LocalDate date = LocalDate.now();

	@BeforeEach
	void setUp() throws Exception {
		detail = new AuditDetail("Internal", date, auditQuestion);
	}

	@Test
	void testHashCodes() {
		AuditDetail tempAuditDetail = new AuditDetail("Internal", date, auditQuestion);
		assertEquals(detail.hashCode(), tempAuditDetail.hashCode());
	}

	@Test
	void testEquals() {
		AuditDetail tempAuditDetail = new AuditDetail("Internal", date, auditQuestion);
		assertEquals(detail, tempAuditDetail);
	}

	@Test
	void testToString() {
		String result = "AuditDetail(auditType=" + detail.getAuditType() + ", date=" + detail.getDate()
				+ ", auditQuestion=" + detail.getAuditQuestion() + ")";
		assertEquals(detail.toString(), result);
	}

	@Test
	void testGetSetAuditType() {
		detail.setAuditType("Internal");
		assertEquals("Internal", detail.getAuditType());
	}

	@Test
	void testGetSetAuditDate() {

		detail.setDate(date);
		assertEquals(date, detail.getDate());
	}

	@Test
	void testGetSetAuditQuestion() {
		detail.setAuditQuestion(auditQuestion);
		assertEquals(auditQuestion, detail.getAuditQuestion());
	}

	@Test
	void auditDetailConstructor() {
		detail = new AuditDetail();
		assertNotNull(detail);
	}

	@Test
	void testauditDetailParameterizedConstructor() {
		AuditDetail auditdetails = new AuditDetail("Internal", date, auditQuestion);
		assertEquals("Internal", auditdetails.getAuditType());
	}
}
