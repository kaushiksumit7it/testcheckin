package com.cognizant.auditmanagementportal.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 
 * This class contains test cases for the AuditQuestion model class which are
 * written using junit and mockito
 */

@SpringBootTest
class AuditQuestionTest {

	@Mock
	AuditQuestion questions;

	@BeforeEach
	void setUp() throws Exception {
		questions = new AuditQuestion(1, "Internal", "Is data deleted with permission of user?", "Yes");
	}

	/**
	 * Checking if AuditQuestion class is loading or not.
	 */
	@Test
	@DisplayName("Checking if AuditQuestion class is loading or not.")
	void claimIsLoadedOrNot() {
		assertThat(questions).isNotNull();
	}

	/**
	 * 
	 * Testing AuditQuestion Constructor
	 */
	@Test
	void testBenefitsConstructor() {
		assertEquals(1, questions.getQuestionId());
		assertEquals("Internal", questions.getAuditType());
		assertEquals("Is data deleted with permission of user?", questions.getQuestion());
		assertTrue("Yes".equalsIgnoreCase(questions.getResponse()));
	}

	/**
	 * 
	 * Testing Getters and setters
	 */
	@Test
	void testGettersSetters() {
		questions.setQuestionId(1);
		questions.setAuditType("Internal");
		questions.setQuestion("Is data deleted with permission of user?");
		questions.setResponse("Yes");
		assertEquals(1, questions.getQuestionId());
		assertEquals("Internal", questions.getAuditType());
		assertEquals("Is data deleted with permission of user?", questions.getQuestion());
		assertTrue("Yes".equalsIgnoreCase(questions.getResponse()));
	}

	@Test
	void testHashCodes() {
		AuditQuestion tempAuditquestion = new AuditQuestion(1, "Internal", "Is data deleted with permission of user?",
				"Yes");
		assertEquals(questions.hashCode(), tempAuditquestion.hashCode());
	}

	@Test
	void testEquals() {
		AuditQuestion tempAuditquestion = new AuditQuestion(1, "Internal", "Is data deleted with permission of user?",
				"Yes");
		assertEquals(questions, tempAuditquestion);
	}

	/*
	 * 
	 * test the AuditQuestion no argsConstructor
	 */

	@Test
	void testNoArgConstructor() {
		AuditQuestion ulc = new AuditQuestion();
		AuditQuestion ulc1 = new AuditQuestion();
		assertEquals(ulc, ulc1);
	}

	/*
	 * 
	 * test the AuditQuestion toString()
	 */
	@Test
	void testToString() {
		String result = "AuditQuestion(questionId=" + questions.getQuestionId() + ", auditType="
				+ questions.getAuditType() + ", question=" + questions.getQuestion() + ", response="
				+ questions.getResponse() + ")";
		assertEquals(questions.toString(), result);
	}

}