package com.cognizant.auditmanagementportal.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuditTypeTest {

	@Mock
	AuditType type;

	@BeforeEach
	void setUp() throws Exception {
		type = new AuditType("Internal");
	}

	/**
	 * Checking if AuditType class is loading or not.
	 */
	@Test
	@DisplayName("Checking if AuditType class is loading or not.")
	void claimIsLoadedOrNot() {
		assertThat(type).isNotNull();
	}

	/**
	 * 
	 * Testing AuditType Constructor
	 */
	@Test
	void testBenefitsConstructor() {
		assertEquals("Internal", type.getAuditType());
	}

	/**
	 * 
	 * Testing Getters and setters
	 */
	@Test
	void testGettersSetters() {

		type.setAuditType("Internal");
		assertEquals("Internal", type.getAuditType());
	}

	@Test
	void testHashCodes() {
		AuditType tempAuditquestion = new AuditType("Internal");
		assertEquals(type.hashCode(), tempAuditquestion.hashCode());
	}

	@Test
	void testEquals() {
		AuditType tempAuditquestion = new AuditType("Internal");
		assertEquals(type, tempAuditquestion);
	}

	/*
	 * 
	 * test the AuditType no argsConstructor
	 */

	@Test
	void testNoArgConstructor() {
		AuditType ulc = new AuditType();
		AuditType ulc1 = new AuditType();
		assertEquals(ulc, ulc1);
	}

	/*
	 * 
	 * test the AuditType toString()
	 */
	@Test
	void testToString() {
		String result = "AuditType(auditType=" + type.getAuditType() + ")";
		assertEquals(type.toString(), result);
	}

}
