package com.cognizant.auditmanagementportal.model;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtRequestTest {
	@Mock
	JwtRequest detail;

	@BeforeEach
	void setUp() throws Exception {
		detail = new JwtRequest("lakshmi", "lakshmi");
	}

	@Test
	void testHashCodes() {
		JwtRequest tempJwtRequest = new JwtRequest("lakshmi", "lakshmi");
		assertEquals(detail.hashCode(), tempJwtRequest.hashCode());
	}

	@Test
	void testEquals() {
		JwtRequest tempJwtRequest = new JwtRequest("lakshmi", "lakshmi");
		assertEquals(detail, tempJwtRequest);
	}

	@Test
	void testToString() {
		String result = "JwtRequest(userName=" + detail.getUserName() + ", password=" + detail.getPassword() + ")";
		assertEquals(detail.toString(), result);
	}

	@Test
	void testGetSetUserName() {
		detail.setUserName("lakshmi");
		assertEquals("lakshmi", detail.getUserName());
	}

	@Test
	void testGetSetPassword() {

		detail.setPassword("lakshmi");
		assertEquals("lakshmi", detail.getPassword());
	}

	@Test
	void auditDetailConstructor() {
		detail = new JwtRequest();
		assertNotNull(detail);
	}

	@Test
	void testauditDetailParameterizedConstructor() {
		JwtRequest auditdetails = new JwtRequest("lakshmi", "lakshmi");
		assertEquals("lakshmi", auditdetails.getUserName());
	}
}
