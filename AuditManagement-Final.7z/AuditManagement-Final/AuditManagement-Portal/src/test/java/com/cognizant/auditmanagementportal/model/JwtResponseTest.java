package com.cognizant.auditmanagementportal.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtResponseTest {

	@Mock
	JwtResponse type;

	@BeforeEach
	void setUp() throws Exception {
		type = new JwtResponse("abcde");
	}

	/**
	 * Checking if JwtResponse class is loading or not.
	 */
	@Test
	@DisplayName("Checking if JwtResponse class is loading or not.")
	void claimIsLoadedOrNot() {
		assertThat(type).isNotNull();
	}

	/**
	 * 
	 * Testing JwtResponse Constructor
	 */
	@Test
	void testBenefitsConstructor() {
		assertEquals("abcde", type.getToken());
	}

	/**
	 * 
	 * Testing Getters and setters
	 */

	@Test
	void testHashCodes() {
		assertEquals(type.hashCode(), type.hashCode());
	}

	@Test
	void testEquals() {
		assertEquals(type, type);
	}

}
