package com.cognizant.auditmanagementportal.model;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * 
 * This class contains test cases for the ProjectDetails model class which are
 * written using junit and mockito
 */

@SpringBootTest
class ProjectDetailsTest {

	@Mock
	ProjectDetails details;

	@BeforeEach
	void setUp() throws Exception {
		details = new ProjectDetails("abc", "abc", "abc");
	}

	/**
	 * Checking if ProjectDetails class is loading or not.
	 */
	@Test
	@DisplayName("Checking if ProjectDetails class is loading or not.")
	void claimIsLoadedOrNot() {
		assertThat(details).isNotNull();
	}

	/**
	 * 
	 * Testing ProjectDetails Constructor
	 */
	@Test
	void testBenefitsConstructor() {
		assertEquals("abc", details.getProjectName());
		assertEquals("abc", details.getProjectManagerName());
		assertEquals("abc", details.getApplicationOwnerName());
	}

	/**
	 * 
	 * Testing Getters and setters
	 */
	@Test
	void testGettersSetters() {
		details.setProjectName("abc");
		details.setProjectManagerName("abc");
		details.setApplicationOwnerName("abc");
		assertEquals("abc", details.getProjectName());
		assertEquals("abc", details.getProjectManagerName());
		assertEquals("abc", details.getApplicationOwnerName());
	}

	@Test
	void testHashCodes() {
		ProjectDetails tempAuditquestion = new ProjectDetails("abc", "abc", "abc");
		assertEquals(details.hashCode(), tempAuditquestion.hashCode());
	}

	@Test
	void testEquals() {
		ProjectDetails tempAuditquestion = new ProjectDetails("abc", "abc", "abc");
		assertEquals(details, tempAuditquestion);
	}

	/*
	 * 
	 * test the ProjectDetails no argsConstructor
	 */

	@Test
	void testNoArgConstructor() {
		ProjectDetails ulc = new ProjectDetails();
		ProjectDetails ulc1 = new ProjectDetails();
		assertEquals(ulc, ulc1);
	}

	/*
	 * 
	 * test the ProjectDetails toString()
	 */
	@Test
	void testToString() {
		String result = "ProjectDetails(projectName=" + details.getProjectName() + ", projectManagerName="
				+ details.getProjectManagerName() + ", applicationOwnerName=" + details.getApplicationOwnerName() + ")";
		assertEquals(details.toString(), result);
	}

}