package com.cognizant.auditmanagementportal.model;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestionListWrapperTest {
	@Mock
	QuestionListWrapper detail;

	List<AuditQuestion> questionList = new ArrayList<AuditQuestion>();

	@BeforeEach
	void setUp() throws Exception {
		detail = new QuestionListWrapper(questionList);
	}

	@Test
	void testHashCodes() {
		QuestionListWrapper tempQuestionListWrapper = new QuestionListWrapper(questionList);
		assertEquals(detail.hashCode(), tempQuestionListWrapper.hashCode());
	}

	@Test
	void testEquals() {
		QuestionListWrapper tempQuestionListWrapper = new QuestionListWrapper(questionList);
		assertEquals(detail, tempQuestionListWrapper);
	}

	@Test
	void testToString() {
		String result = "QuestionListWrapper(questionList=" + detail.getQuestionList() + ")";
		assertEquals(detail.toString(), result);
	}

	@Test
	void testGetSetAuditQuestion() {
		detail.setQuestionList(questionList);
		assertEquals(questionList, detail.getQuestionList());
	}

	@Test
	void auditDetailConstructor() {
		detail = new QuestionListWrapper();
		assertNotNull(detail);
	}

	@Test
	void testauditDetailParameterizedConstructor() {
		QuestionListWrapper auditdetails = new QuestionListWrapper(questionList);
		assertEquals(questionList, auditdetails.getQuestionList());
	}
}
