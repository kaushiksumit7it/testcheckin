package com.cognizant.pharmacymanagement.MedicinesSupply;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * This class contains MedicinesSupplyApplication test cases
 *
 */
@SpringBootTest
class MedicinesSupplyApplicationTests {

	@Test
	void contextLoads() {
	}

}
