package com.cognizant.pharmacymanagement.RepresentativeSchedule;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * This class contains RepresentativeScheduleApplication test cases
 *
 */
@SpringBootTest
class RepresentativeScheduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
