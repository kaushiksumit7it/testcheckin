INSERT INTO userdata (user_id,user_password,user_name) VALUES ('admin','pwd','admin');
INSERT INTO userdata (user_id,user_password,user_name) VALUES ('admin1','admin1','admin1');
