package com.cognizant.pharmacymanagement.WebPortal.Model;

public class AuthResponse {
	private String uid;
	private String name;
	private boolean isValid;
}
